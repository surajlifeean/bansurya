<?php if(Session::has('success')): ?>
	
	<div class="alert alert-success" role="alert" style="width:400px; margin-left:5%">

		<strong>Success:</strong><?php echo e(Session::get('success')); ?>

	</div>
	
<?php endif; ?>