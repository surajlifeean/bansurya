 <div class="rightPanelCart">
					<div class="rightPanelCartWrapper">
			<!-- <div class="couponDetails">
			<h2 class="couponTitle">
				Coupons <span class="pull-right">
				<a href="#CouponModal" data-toggle="modal" class="btn">Apply Coupon</a></span>
				<a href="#" class="btn">Edit</a></span>
			</h2>
			<p class="couponSavedAmount">You saved <span>Rs.400</span></p>
																</div>-->

	<!-- -------Promotion code discount amount--------------- -->
		
	<!-- -------Promotion code discount amount end--------------- -->
		                      
	<div class="priceDetails">
		<h3 class="couponTitle">Price Details</h3>
		<p class="title">Bag Total: 
			<span class="pull-right">
				Rs. 
				<span id="grand_total_price_summery"><?php echo e($totalprice); ?></span>
			</span>
		</p>
		<p class="title">Bag Discount: 
			<span class="pull-right">
				Rs. 
				<span id="discount_price_summery"> 
					<?php echo e($totaldiscount); ?>

				</span>
			</span>
		</p>
		<p class="title">Estimated VAT: 
			<span class="pull-right">
				Rs. 
				<span id="vat_price_summery"> 
					0 
				</span>
			</span>
		</p>
		<!-- <p class="title">Coupon Discount: <span class="pull-right">
			<a href="javascript:void(0);" style="cursor: default;">
				 Not Applied 			</a></span>
		</p> -->
		<p class="title">Shipping Cost: <span class="pull-right">FREE</span></p>
	</div>
	<div class="orderDetails">
		<h3 class="couponTitle">Order Total 
			<span class="pull-right">
				Rs. 
				<span id="order_total_summery"><?php echo e($totalprice-$totaldiscount); ?></span>
				<input type="hidden" id="bag-total-balance" value="1949">
			</span>
		</h3> 
		
								<!-- <p class="title">Wallet Balance Used: 
					<span class="pull-right">
						Rs. 
						<span id="is-wallet-used"> 
							0 
						</span>
					</span>
				</p>
				<p class="title">From Your Account 
			<span class="pull-right">
				Rs. 
				<span id="order_total_summery_to_pay_from_account"> 
					1949  
				</span>
			</span>
		</p> -->
				
						<form action="" method="post">

						<button type="submit" class="btn btn-primary">Checkout</button> 

				</form>	
		       <h6 class="proceed-to-checkout-error-msg error"></h6> 
	</div>                        
</div>
<div class="rightPanelBottom">
	<p>Need Help?<br>Call us on (022) 3077 0260</p>
</div>

</div>
