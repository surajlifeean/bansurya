<?php $__env->startSection('stylesheets'); ?>

	<style type="text/css">


/*
  .navbar-default {
    background-color:  #d8fefa;
    border-color: #030033;
}
*/
.img-circle {

    border-radius: 360px;
    max-width: 80%;      
    
}

.cardheader{
  background-color: #FFB400;
  background-size: cover;
  height:90px;
}
.avatar{
  position: relative;
  top:-50px;
  margin-bottom: -50px;
}

.avatar img{
  vertical-align:center;
  border-radius: 50%;
  border:9px solid #fff;
}

.info{
  padding: 4px 8px 10px;
}

.title{
  margin-bottom: 4px;
  font-size: 20px;
  color: #262626;
 
  vertical-align: middle;
}

.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
}

.tab-pane{
  position: relative;
}

.tab-content>.active{
  display: block;
}

span.personalInfoValue {
    color: #292929;
    font-size: 18px;
    font-family: 'montserratRegular';
    width: 100%;
    display: block;
    padding: 2px 0;
    }

    .personalInfoWrapper label {
    font-weight: 400;
    font-family: 'montserratRegular';
    font-size: 15px;
    text-transform: uppercase;
    color: #9a9a9a;
    margin: 0;
    padding: 0;
    width: 100%;
}



.personalInfoWrapper .personalInfoIcon:before {
    display: inline-block;
    font: normal normal normal 22px/1 FontAwesome;
    position: absolute;
    left: 0;
    top: 0;
    width: 42px;
    height: 42px;
    background: #f2f2f2;
    border-radius: 100%;
    text-align: center;
    line-height: 42px;
    color: #292929;
}

.editBtn{
      position: absolute;
    top: -80px;
    right: -16px;
    background: #f2f2f2;
    width: 75px;
    height: 30px;
    color: #292929;
    font-size: 12px;
    text-transform: uppercase;
    line-height: 30px;
    padding: 0 0 0 10px;
    cursor: pointer;
    font-family: 'montserratRegular';
}
}
.glyphicon { margin-right:10px; }
.panel-body { padding:0px; }
.panel-body table tr td { padding-left: 15px }
.panel-body .table {margin-bottom: 0px; }


  </style>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials._imagespace', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container" >
    <div class="row">

<div class="col-sm-3 col-md-3">
            
            <?php echo $__env->make('partials._dashnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>



        <div class="col-sm-9 col-md-9">

    <div class="well">
      <div class="tab-content">
        	<div class="row">



<!-- 
loop to display the wishlist products will be displayed here -->
 <label style="margin-bottom: 10px;">
                      <U>WISHLIST</U></label>


              <div class="tab-pane personalInfoWrapper active">
                  <div class="personalInfoView">
<?php $__currentLoopData = $subproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<div class="card col-sm-12 col-md-4">
            <?php 
      $img=$sproduct->images[0]->name
     ?>
        
                
  <!--     <img src="<?php echo e(asset('http://127.0.0.1:8080/images/'.$img)); ?>"  alt="bansuriya">
   -->
         <img class="card-img-top" src="<?php echo e(asset('http://127.0.0.1:8080/images/'.$img)); ?>" alt="Card image cap" width="60%" height="30%">
          <div class="card-block">
            <h4 class="card-title"><?php echo e($sproduct->product->name); ?></h4>
            <p class="card-text">
            	<strike> Rs<?php echo e($sproduct->price); ?></strike>
    <?php if($sproduct->discount_type=="Percentage"): ?>
        Rs<?php echo e($sproduct->price-($sproduct->price*$sproduct->discount)/100); ?>

        (<?php echo e($sproduct->discount); ?>% OFF)
    <?php else: ?>
         Rs<?php echo e($sproduct->price-$sproduct->discount); ?>(<?php echo e(floor($sproduct->discount*100/$sproduct->price)); ?>% OFF) 
    <?php endif; ?>

            </p>
            <!-- <p class="card-text"><small class="text-muted">Add to Bag</small> <small class="text-muted" style="margin-left: 10px;"><a href="">
             -->

             <?php echo Form::open(array('route'=>'cart.store')); ?>


  <input type="hidden" value="<?php echo e($sproduct->id); ?>" id="subproduct" name="subproduct_id">

  <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" id="id" name="user_id">
  
  
              <button class="add-to-cart btn btn-primary" type="submit">add to cart</button>

   <?php echo Form::close(); ?>

       
                    <?php echo Form::open(['route'=>['wishlist.destroy',$sproduct->id],'method'=>'DELETE']); ?>



                           <?php echo Form::submit('Remove',array('class'=> 'btn-default btn')); ?>


                    <?php echo Form::close(); ?>

</a></small></p>
          </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>


      </div>


    </div>




</div>
</div>


</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>