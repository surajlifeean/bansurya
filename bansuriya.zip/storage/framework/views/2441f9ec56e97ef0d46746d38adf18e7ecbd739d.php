
    <footer class="footer-distributed" >

<!-- <?php if(Session::has('sent')): ?>
  
  <div class="alert alert-success" role="alert" style="width:400px; margin-left:10%">

    <strong>Done:</strong><?php echo e(Session::get('sent')); ?>

  </div>
  
<?php endif; ?>
 -->

 <div id="forfocus"></div>
<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>


       <div class="footer-left">

        <h3>Ban<span>suriyaa</span></h3>

        <p class="footer-links">
          <a href="<?php echo e(route('home')); ?>">Home</a>
          ·
          <a href="<?php echo e(route('policy')); ?>">Privacy Policy</a>
          ·
          <!-- <a href="#">Pricing</a>
           -->
          <a href="<?php echo e(route('aboutus')); ?>">About Us</a>
          ·
          <!-- <a href="#">Faq</a>
          ·
          <a href="#">Contact</a> -->
        </p>

        <p class="footer-company-name">Bansuriya &copy; 2017. Powered By AIDA Labs</p>

        <div class="footer-icons">

          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-linkedin"></i></a>

        </div>

      </div>

      <div class="footer-right">

        <p>Contact Us</p>
    <?php echo Form::open(array('route'=>'contactus')); ?>


          <input type="text" name="email" placeholder="Email" id="email" />

          <textarea name="message" placeholder="Message" id="message"></textarea>
          <button class="submit">Send</button>
    <?php echo Form::close(); ?>



      </div>

    </footer>
<script type="text/javascript">

// function getfocus(){
//       document.getElementById('forfocus').focus();

//   }


</script>