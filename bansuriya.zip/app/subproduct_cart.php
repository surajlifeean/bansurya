<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subproduct_cart extends Model
{
    //
}
