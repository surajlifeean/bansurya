<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Category;

use App\subproduct;

use App\Subcategory;

class SubproductController extends Controller
{
    public function show($id)
    {
    }
}
