<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profileimage extends Model
{
    //
}
