

  <title>Bansuriyaa @yield('title')</title> <!--change title in each page -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="http://127.0.0.1:8000/css/demo.css">
  <link rel="stylesheet" href="http://127.0.0.1:8000/css/footer-distributed-with-contact-form.css">


  <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  
<style>
/*
body { padding-top: 70px; }*/
 /* nav bar*/
.example3 .navbar-brand {
  height: 70px;

}

.example3 .nav >li >a {
  padding-top: 30px;
  padding-bottom: 30px;

}
.example3 .navbar-toggle {
  padding: 10px;
  margin: 25px 15px 25px 0;
}

    .nav-tabs {
    margin-bottom: 15px;
}
.sign-with {
    margin-top: 25px;
    padding: 20px;
}
div#OR {
    height: 30px;
    width: 30px;
    border: 1px solid #C2C2C2;
    border-radius: 50%;
    font-weight: bold;
    line-height: 28px;
    text-align: center;
    font-size: 12px;
    float: right;
    position: absolute;
    right: -16px;
    top: 40%;
    z-index: 1;
    background: #DFDFDF;
}

@font-face {
    font-family: myFirstFont;
    src: url(http://127.0.0.1:8000/sanam.TTF);
}


#navbar3 {
        font-family: myFirstFont;

    font-size: 20px;


}
.staticheading{

    font-family: myFirstFont;
}

</style>

<script>

    $('#myModal').modal('show');

</script>


    
